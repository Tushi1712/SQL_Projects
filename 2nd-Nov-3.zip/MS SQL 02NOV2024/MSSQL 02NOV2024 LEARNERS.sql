

TODAY AGENDA---- 02/NOV/2024

--JOINS : LEFT JOIN

--1) LEFT JOIN

SELECT * FROM EMP E INNER JOIN DEP D ON E.DepartmentID = D.DepartmentID;
SELECT * FROM EMP E LEFT JOIN DEP D ON E.DepartmentID = D.DepartmentID;

SELECT * FROM EMP


SELECT * FROM EMP E RIGHT JOIN DEP D ON E.DepartmentID = D.DepartmentID;

SELECT * FROM DEP;


SELECT * FROM EMP E FULL JOIN DEP D ON E.DepartmentID = D.DepartmentID;

--UPDATE AND DELETE

SELECT * fROM EMP;

REQUIREMENT: Hi Nisha, please change the empid #1 first name to JHON insteado john


--UPDATE SYNTAX
-- UPDATE TABLE_NAME SET COLUMN_NAME = 'UPDATED/NEW VALUE' WHERE CONDITION.....

UPDATE EMP SET FirstName= 'JHON' WHERE EmployeeID=1;


SELECT * fROM EMP;

--DELETE 
---SYNTAX
-- DELETE FROM TABLE_NAME WHERE CONDITION....

DELETE FROM EMP WHERE EMPLOYEEID=4;

SELECT * fROM EMP;

---PENDING ITEM#1:  MERGE STATEMENT


-- MODULE 4

---- ALTER COMMAND ----
DATABASE RE-NAME
TABLE RE-NAME
COLUMN RE-NAME
ADD COLUMN
DROP COLUMN 
CHANGE DATATYPE
CHANGE LENGTH OF THE DATATYPE

--DATABASE RE-NAME
--SYNTAX TO RENAME THE DATABASE
--SP_RENAMEDB OLD_dB_NAME, NEW_DB_NAME;

SP_RENAMEDB TESLA,TESLA_TEXAS;

--SP: STORED PROCEDURES : SET OF CONDITIONS EMMEDED IN THE SQL STATEMENTS 
--TYPES OF SP 1) SYSTEM DEFINED SP. 2) USER DEFINED SP

-- NOTE1 :TO SEE THE LIST OF TABLES WHICH YOU HAVE CREATED IN RESPECTIVE DATABASE;

SELECT * FROM SYSOBJECTS WHERE XTYPE = 'U';

--2) TABLE RE-NAME

--TABLE RE-NAME
--SYNTAX TO RENAME THE TABLE NAME
SP_RENAME OLD_tABLE_NAME, NEW_tABLE_NAME

SP_RENAME EMP, EMP_TEXAS;
SELECT * FROM EMP_TEXAS;

SELECT * FROM EMP;



--3) COLUMN RE-NAME

--COLUMN RE-NAME
--SYNTAX TO RENAME THE COLUMNAME
SP_RENAME 'TABLE_NAME.OLD_cOL_NAME', 'NEW_COL_NAME';

SP_RENAME 'EMP_TEXAS.DEPARTMENTID','DEP_ID';

SELECT * FROM EMP_TEXAS;

--ADD COLUMN
EX: VACCINATED;

-- ADD A NEW COLUMN TO EXSISITNG TABLE;
--SYNTAX
--ALTER TABLE TABLE_NAME ADD COLUMN DATATYPE(LENGTH)

ALTER TABLE EMP_tEXAS ADD VACCINATED VARCHAR(3);

SELECT * FROM EMP_TEXAS;


-- DROP COLUMN 

--DROP A COLUMN IN THE TABLE
--ALTER TABLE TABLE_NAME DROP COLUMN COLUMN_NAME;

ALTER TABLE EMP_tEXAS DROP COLUMN VACCINATED;

SELECT * FROM EMP_TEXAS;



--Note#2: TO SEE THE MetaData/Details /Schema/skeliton of the table;

--sp_help 'tableName'

SP_HELP 'EMP_tEXAS';
SP_HELP 'CUSTOMER_wC';

---CHANGE DATATYPE

--CHANGE DATATYPE
--SYNTAX TO CHANGE THE DATATYPE 
--ALTER TABLE TABLE_NAME ALTER COLUMN COLUMN_NAME NEW_DATATYPE;

ALTER TABLE EMP_tEXAS ALTER COLUMN FIRSTNAME NVARCHAR(50);

SP_HELP 'EMP_tEXAS';

--CHANGE LENGTH OF THE DATATYPE

--SYNTAX TO CHANGE THE DATATYPE 
--ALTER TABLE TABLE_NAME ALTER COLUMN COLUMN_NAME DATATYPE(LENGTH);

ALTER TABLE EMP_tEXAS ALTER COLUMN LASTNAME NVARCHAR(60);

SP_HELP 'EMP_tEXAS';

SP_HELP 'CUSTOMER_wC';
ALTER TABLE CUSTOMER_wC ALTER COLUMN L_NAME VARCHAR(70);

SP_HELP 'CUSTOMER_wC';


---TEMPORARY TABLES;
-- ARE USED FOR INTERMEDIATARY RESULTS,COMPLEX CALICULATIONS, ISOLATION.

Def: A temporary table is a temporary variable that holds a table. 
	A temporary table is used as a buffer or intermediate storage for table data. 
	You can use a temporary table just like you use a database table.


	-- TYPES OF TEMP TABLES

LOCAL TEMP TABLES : ITS A SINGLE SESSION, BY SINGLE USER, #TEMPTABLE (eX: #EMPLOYEE );
GLOBAL TEMP TABLES : Multi sessionS and multi users, ##TEMPTABLE


Requirement#1 : Hi Rashmi, please provide the Excellent Ratings employee details, 
				add 1% bonus to them and send me the report;


--STEP1 : CREATE EMP TEMP / TAKE THE NECCESSARY TABLE
--STEP2 : CREATE TEMP TABLE
--STEP3: SOME CONDITIONS ON TEMP TABLE

--STEP1:CREATE A emp TABLE

CREATE TABLE EMLPOYEE777
(
    EID INT,
    ENAME VARCHAR(50),
    ESALARY MONEY,
    EAGE INT,
    EGENDER VARCHAR(6),
    EDEPT VARCHAR(25),
	ERATINGS VARCHAR(25)
);

INSERT INTO EMLPOYEE777 (EID, ENAME, ESALARY, EAGE, EGENDER, EDEPT, ERATINGS) VALUES
(1, 'John Doe', 50000.00, 35, 'Male', 'IT', 'Excellent'),
(2, 'Jane Smith', 60000.00, 32, 'Female', 'HR', 'Good'),
(3, 'Bob Johnson', 75000.00, 31, 'Male', 'Finance', 'Excellent'),
(4, 'Alice Williams', 80000.00, 33, 'Female', 'Marketing', 'Average'),
(5, 'Charlie Brown', 55000.00, 37, 'Male', 'Sales', 'Good'),
(6, 'Diana Miller', 70000.00, 36, 'Female', 'IT', 'Excellent'),
(7, 'Edward Davis', 62000.00, 34, 'Male', 'HR', 'Good'),
(8, 'Fiona Clark', 68000.00, 38, 'Female', 'Finance', 'Excellent'),
(9, 'George Wilson', 53000.00, 35, 'Male', 'Marketing', 'Average'),
(10, 'Helen Taylor', 72000.00, 33, 'Female', 'Sales', 'Good'),
(11, 'Isaac Turner', 62000.00, 28, 'Male', 'IT', 'Excellent'),
(12, 'Jessica Carter', 55000.00, 22, 'Female', 'HR', 'Good'),
(13, 'Kevin White', 68000.00, 30, 'Male', 'Finance', 'Excellent'),
(14, 'Lily Morgan', 50000.00, 24, 'Female', 'Marketing', 'Average'),
(15, 'Michael Walker', 72000.00, 26, 'Male', 'Sales', 'Good'),
(16, 'Natalie Hall', 60000.00, 29, 'Female', 'IT', 'Excellent'),
(17, 'Oliver Davis', 67000.00, 23, 'Male', 'HR', 'Good'),
(18, 'Penelope Reed', 58000.00, 27, 'Female', 'Finance', 'Excellent'),
(19, 'Quentin Adams', 53000.00, 25, 'Male', 'Marketing', 'Average'),
(20, 'Rachel Hill', 65000.00, 22, 'Female', 'Sales', 'Good'),
(21, 'Samuel Turner', 71000.00, 30, 'Male', 'IT', 'Excellent'),
(22, 'Tiffany Gonzalez', 59000.00, 28, 'Female', 'HR', 'Good'),
(23, 'Ulysses Rodriguez', 68000.00, 29, 'Male', 'Finance', 'Excellent'),
(24, 'Victoria Lopez', 54000.00, 27, 'Female', 'Marketing', 'Average'),
(25, 'William Foster', 69000.00, 24, 'Male', 'Sales', 'Good'),
(26, 'Xavier Parker', 61000.00, 26, 'Male', 'IT', 'Excellent'),
(27, 'Yvonne Stewart', 58000.00, 31, 'Female', 'HR', 'Good'),
(28, 'Zachary Reed', 70000.00, 33, 'Male', 'Finance', 'Excellent'),
(29, 'Abigail Cooper', 56000.00, 28, 'Female', 'Marketing', 'Average'),
(30, 'Benjamin Turner', 73000.00, 35, 'Male', 'Sales', 'Good');



 select * From EMLPOYEE777;

 --2) creation of Temp Table;


 --CREATE THE TEMP TABLE

CREATE TABLE #TEMPTABLE_EMLPOYEE777
(
    EID INT,
    ENAME VARCHAR(50),
    ESALARY MONEY,
    EAGE INT,
    EGENDER VARCHAR(6),
    EDEPT VARCHAR(25),
	ERATINGS VARCHAR(25)
);

select * from EMLPOYEE777
SELECT * FROM #TEMPTABLE_EMLPOYEE777


--3)

INSERT INTO #TEMPTABLE_EMLPOYEE777 (eid,ename,esalary,eage,egender,edept,eratings)
SELECT eid,ename,esalary,eage,egender,edept,eratings FROM EMLPOYEE777 
WHERE ERATINGS = 'EXCELLENT'; 


select * from EMLPOYEE777
SELECT * FROM #TEMPTABLE_EMLPOYEE777

--UPDATE: '
UPDATE #TEMPTABLE_EMLPOYEE777 SET ESALARY = ESALARY*1.01;

SELECT * FROM #TEMPTABLE_EMLPOYEE777



---LUNCH /DINNER BREAK FOR 15 MINUTES 



--DATABASES AND ITS TYPES 

1) SYSTEM DEFINED DATABASES 
2) USER DEFINED DATABASES

1) SYSTEM DEFINED DATABASES
  MASTER: ALL SYSTEM LEVEL INFORMATION, INSTANCES, LOGINACCOUTNS, CONFIG
  MODEL: TEMPLATES OF DB
  MSDB: SQL SERVER AGENT JOBS, ALERTS,BACKUP, RESTORE
  , TEMPDB: TEMPORARY WORKSPACE 

2) USER DEFINED DATABASES : USER CREATED DB: EX: TESLA, TESLA_TEXAS


--4) SQL SERVER FUNCTIONS:

--DEF: FUNCTIONS: ARE PREDEFINED COMMANDS ARE USED FOR COMMONTASKS:
--- TYPES: SYSTEM DEFINED FUNCTIONS AND USER DEFINED FUNCTIONS

--1) SYSTEM DEFIND FUNCTIONS are built-in COMMANDS provided by the 
	system or database platform for common tasks & Caliculations.

--2) USER DEFINED FUNCTIONS: WHICH ARE CREATED BY USERS, TO CREATE A 
			SET A COMMANDS FOR PROGRAMMING & CALICULATIONS:


--AGGREGATIONS FUNCTIONS ( SUM, COUNT, AVG, MIN AND MAX)

USE TESLA_TEXAS

SELECT * FROM CarSales;
--1.) AGGREGATIONS FUNCTIONS ( SUM, COUNT, AVG, MIN AND MAX)
SELECT SUM(CGS) as cgs FROM CarSales;

SELECT count(*) as Countt FROM CarSales;

SELECT avg(profit) as Countt FROM CarSales;

SELECT min(profit) as Countt FROM CarSales;

SELECT max(profit) as Countt FROM CarSales;

--1.2)  Date Functions

SELECT GETDATE();--today's date
SELECT CURRENT_TIMESTAMP;  -- DATABASE_DATe AND TIME FORMAT
SELECT GETUTCDATE();  -- CURRENT UTC DATE (Coordinated Universal Time)
SELECT SYSDATETIME(); -- CURRENT DATE & TIME WITH PRECISION (FRACTION OF SECONDS)
SELECT SYSUTCDATETIME(); 

--1.3) String functions: allowS you to manipulate and work with 
		---string data. Some common string functions include:
 Ltrim
 Rtrim
 Upper
 Lower
 Substring
 REVERSE


 CREATE TABLE EmpTable 
(
    ID INT PRIMARY KEY,
    Name VARCHAR(50)
);


INSERT INTO EmpTable (ID, Name) VALUES (1, '   John');
INSERT INTO EmpTable (ID, Name) VALUES (2, '  Alice');
INSERT INTO EmpTable (ID, Name) VALUES (3, '   Bob ');
INSERT INTO EmpTable (ID, Name) VALUES (4, 'KRANTHI ');
INSERT INTO EmpTable (ID, Name) VALUES (5, 'LOKESH');
INSERT INTO EmpTable (ID, Name) VALUES (6, 'HARI');


select id, ltrim(name) as NAME from EmpTable;

select id, rtrim(name) as NAME from EmpTable;

select * From emptable

select id, Ltrim(upper(name)) as NAME from EmpTable;

select id, Ltrim(lower(name)) as NAME from EmpTable;

 Upper
 Lower



 Substring
 REVERSE


 --substring
--INTERVIEW QUESTION: WAQ to retrieve the first six characters 
			--of the salesperson./product 

select * From CarSales

select SUBSTRING(salespersonName,1,6), SalespersonName from CarSales; 

 
select REVERSE(salespersonName), SalespersonName from CarSales; 


--SYTEM FUNCTIONS AND WINDOWS FUNCTIONS: TOMORROW 8PM IST 


