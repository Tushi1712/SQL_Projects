--------------WELCOME TO INTELIPAAT

--- GOOD MORNING AND GOOD EVENING ALL !!

-- I'M KRANTHI , YOUR SQL TRAINER 

=========================================================================
-------------------------------MS SQL -----------------------------
=========================================================================

--1) History

HUMAN   
MACHINERY
COMPUTERS
INTERNET
AI

HUMAN  & START AND ENDS WITH INTERNET 

--2) DATABASE : IT STORES ANY TYPE OF DATA AND ANY AMOUNT DATA , SECURELY,
				AND RETRIEVE IN FASTER WAY.


--3) APPLICATION: WEBSITE/MOBILEAPP/REPORTING APPLICATIONS
----------------------------------------------------------
-- 3.1) FRONT END TOOLS: HTML /CSS/ JAVASCRIPT /FRAMEWORKS

--- 3.2) BACK END TOOLS: ASP.NET , JAVA, DATABASES

--->DATABASES: DATABASE OBJECTS : DATABASE, TABLE, VIEW, SP, FUNCTIONS & ETC 



--4) MS SQL : MICROSOFT SQL / MS SQL SERVER / SQL SERVER /

--5) SQL : STRUCTURED QUERY LANGUAGE : IT MANAGES AND MANIPULATES THE DB.

-- 6) DIFFERENCE B/W:  SQL VS MSSQL VS SQL SERVER VS MYSQL VS ORACLE SQL VS POSTGRESQL
--------------------------------------------------------------------------
--LAYMEN EXAMPE 

YOU(LEARNERS)= FRENCH & ENGLISH  ---- > LANG(ENGLISH)  <------- HINDI & ENGLISH

USERS (EVERYONE) ---------------------> SQL(MS SQL)    <----- DATABASE  

--LAYMEN EXAMPE2 

DRIVING   --->   SQL
NISSAN CAR --->  MS SQL 
----------------------------

--SQL	: STRUCTERED QUERY LANGUAGE 
--MS SQL: ITS A RDBMS PRODUCT, DEVELOPED BY MIRCROSOFT IN 1989.
--MYSQL : ITS A RDBMS PRODUCT, DEVLOPED BY ORACLE FOR SMAL & MED PROJECTS
--ORACLEDB: ITS A RDBMS PRODUCT, DEVLOPED BY ORACLE FOR LARGE ENTPRSE PROJECTS
--POSTGRESQL:ITS A RDBMS PRODUCT, DEVLOPED BY POSTGRESQL
--DB2 : ITS A RDBMS PRODUCT, DEVLOPED BY IBM


SQL			DRIVING
-------------------------------	
MSSQL		BWM 
MYSQL		NISSAN
ORACLE		RANULT
POSTGRESQL	FORD
DB2			HONDA

--7)
MSSQL : VERSIONS AND EDITIONS
---------------------------------------
--MS SQL SERVER 2022

2022
2019
2017
2015
2013
2011


--EDITIONS
STANDARD, DEVELOPER, ENTEPRISE 


--LAYMEN EX:
IPHONE
----------------------------------
VERSIONS : EDITIONS
IPHONE16 : IPHONE 16 MINI
		  IPHONE 16 PRO
		  IPHONE 16 MAX


--8)
DATA		:  RAW INFORMATION : 1990,MBA,BETCH,KRANTHI, ASHISH,SAYANI.
INFORMATION : ORGANISED DATA: KRANTHI DOB 1990, HE COMPLETED BTECH, ASHISH DOB2000 HE COMPLETED MBA
DATABASE	:	IT STORES ANY TYPE OF DATA AND ANY AMOUNT OF DATA TO STORE,
	             SECURELY AND RETRIVE FASTER WAY.

DBMS        : DATABASE MANAGEMENT SYSTEMS: ITS AN ENVIRONMENT WHERE IT HANDLES & MAGANGES
				THE DATABASES 
			: TYPES OF DBMS: HDBMS, NDBMS, ODBMS, RDBMS BY EF CODD 1973

RDBMS : RELATIONAL DBMS : IT CREATES THE REALTIONSHIP B/W TABLES AND 
						  -- STORES THE DATA IN TABULAR FORMAT (ROWS AND COLOUMNS)


---9) 
GUI : GRAPHICAL USER INERFACE : DRAG AND DROP / USING CURSOR
CLI : COMMAND LINE INTERFACE : WRITE THE CODE/SCRIPT 

--10) 
---INSTANCE = SERVER (50 SERVERS/INSTANCES)

1 -- DEFUALT INSTANCE/SERVER
49 -- NAMED INSTANCES/SERVERS


-- REGIONS: 1 INSTANCE - MAINBRANCH (CA)
			2 INSTANCE -- NEWYORK
			3 INSTANCE -- OHIO
			ETC  TILL 50 INSTANCES

-- DEPLOYMENT : DEVELOPMENT SERVER  (1 INSTANCE)
				TESTING SERVER (2 INSTANCE)
				LIVE SERVER (3 INSTANCE)

-- CATOGORIES, OTHER THINGS 

--11) MORE DETAILS 
----------------------
SSMS:
1 INSTANCE -- 32767 DATABASES 
1 DATABASE -- 16k TABLES
1 TABLE -- 1024 COLUMNS 
1 TABLE  -- UNLIMITED ROWS / LIMITED BY STORAGE /EDITIONS


----8 MODULES

-------------------------MODULE 1-------------------------


--12) CATAGORIES OF SQL COMMANDS

	--12.1) DATA QUERY LANGUAGE = DATA RETREIVAL LANGUAGE 
		(DQL /DRL)

		SELECT : IT WILL SELECT THE DATA FROM THE TABLE
		-- SYNTAX : SELECT * FROM TABLE_NAME

			SELECT * FROM CARSALESDATA;

			SELECT SALEID,CARMAKE,PROFIT FROM CARSALESDATA;


			
	--2.2) DATA DEFINATION LANGUAGE (DDL) 
			CREATE , ALTER , DROP :

			TO CREATE/ALTER/DROP THE DATABASE OBJECTS 

			DATABASE OBJECTS: DATABASE, TABLE, VIEW, TRIGGERS, SP , FUNCTIONS ETC 


--2.3) DATA MANIPULATION LANGUAGE (DML)
			-- INSERT, UPDATE, DELETE , TRUNCATE 

		NOTE: DROP VS DELETE VS TRUNCATE 
		-----------------------------------------------------
			DROP: COMPLETE DELETION OF THE DATABASE OBJECT(DB, TABLE, VIEWS ETC) 
			DELETE: DELETE A ROW/S FROM A TABLE 
			TRUNCATE : IT DELETES ALL ROWS FROM A TABLE AND STRUCTURE IS NOT DELETED


	--2.4 DATA CONTROL LANGUAGE (DCL) --> DBA : DATABASE ADMINSTRATION TEAM
			GRANT  : GIVINING ACCES TO USERS / ROLES/PRIVALGES
			REVOKE : STOPPOING ACCES TO USERS /ROLES/PRIVALGES


			T-SQL --> MICROSOFT
			PL SQL --> ORACLE





TODAY ,NOW 
------------------
PLEASE JOIN THE SECOND LINK PROVIDE TO YOU 
WHICH IS IN ANOTHER MAIL 
HAVE A BRAKE FOR 10 MINUTES, JOIN SHARP @ 9.PM IST





--------------WELCOME TO INTELIPAAT--------------------

--- GOOD MORNING AND GOOD EVENING ALL !!

-- I'M KRANTHI , YOUR MSSQL TRAINER 

-------------------------------------------------------

--STILL LEARNERS ARE JOINING, LETS WAIT FOR THEM 


MODULE 1 --DONE



---------------------------MODULE 2-------------------------------------
--1)
--1) CREATION OF DATABASE
--SYNTAX:
--CREATE DATABASE DATABASE_NAMEE;


CREATE DATABASE TESLA;
 

--2) USING THE DATABASE

--SYNTAX
--USE DATABASE_NAMEE

USE TESLA;


--3) Dropping the Database
--SYNTAX
--Drop Database Database_namee

-- STEP1: IF U WANT TO DROP THE DATABASE, FIRST MOVE TO ANOTHER DATABASE(MASTER)
-- STEP2: NOW DROP THE DATABASE

DROP DATABASE TESLA;

USE MASTER;

DROP DATABASE TESLA;

--2) DATA TYPES IN SQL 

---3) CONSTRAINTS
	--IND CUT PF
	-------------------------
	IDENTITY    (TO AUTOMATE THE SEQUENCIAL NUMBERS)
	NOT NULL  
	DEFAULT

	CHECK 
	UNIQUE 
	TRIGGER --LATER ON 

	PRIMARY KEY ( = NOTNULL + UNIQUE)
	FOREIGN KEY ( IT CREATES THE REALTIONSSHIP OTHER TABLE TO AVOID THE ORPHAN DATA)
	--LATER ON DISCUSS: TRIGGERS, Pk VS FK


CREATE DATABASE TESLA;
USE TESLA


--4) CREATION OF TABLE
-------------------------
--SYNTAX

/* 

CREATE TABLE TABLE_NAME
(
COL1 DATATYPE,
COL2 DATATYPE,
COL3 DATATYPE,
.
.
.
COLN DATATYPE
); 


*/

-- CREATING A CUSTOMER TABLE

CREATE TABLE CUSTOMER 
(
CUSTOMER_ID		INT,
F_NAME			VARCHAR(25),
L_NAME			VARCHAR(25),
JOIN_DATE		DATE,
AGE				TINYINT,
EMAIL			VARCHAR(50),
PHONE			INT,
ADDRESSS		VARCHAR(100),
CREDIT_LIMIT	DECIMAL(10,2),
COMMENTS		TEXT
);

---VERIFY MY TABLE
SELECT * FROM CUSTOMER;

--5) INSERT DATA
--SYNTAX

--INSERT INTO TABLE_NAME (COL1,COL2,COL3...) VALUES (VAL1,VAL2,VAL3...);

INSERT INTO CUSTOMER (CUSTOMER_ID, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, ADDRESSS, CREDIT_LIMIT, COMMENTS) VALUES
(1, 'Doe', '2021-01-15', 28, 'john.doe@example.com', 1234567890, '123 Main St, Anytown, USA', 5000.00, 'First customer');

---VERIFY MY TABLE
SELECT * FROM CUSTOMER;

INSERT INTO CUSTOMER (CUSTOMER_ID, F_NAME, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, ADDRESSS, CREDIT_LIMIT, COMMENTS) VALUES
(2, 'Trilochan', 'Das', '2022-05-17', 29, 'Tdas@example.com', 724567899, '569 Hyd St, Anytown, Ameerpet', 10000.00, 'SeconD Customer');


---VERIFY MY TABLE
SELECT * FROM CUSTOMER;



--6) Types of inserting data
-----------------------------------------
-- a) Single Line Insert (above)
-- b) Multi Line Insert (BELOW)
--c) Import Excel sheet/CSV file into the Sql server
--d) Insert data Via application(Website/App by End User)
--e) Import data Via ETL Tools (SSIS, informatica, Snowflake.)

---------------------------------------------------------------------

-- b) Multi Line Insert 

INSERT INTO CUSTOMER (CUSTOMER_ID, F_NAME, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, ADDRESSs, CREDIT_LIMIT, COMMENTS) 
VALUES
(3, 'Emily', 'Jones', '2019-11-12', 22, 'emily.jones@example.com', 345678012, '789 Oak St, Sometown, USA', 1000.00, 'New customer'),
(4, 'Michael', 'Brown', '2023-03-09', 40, 'michael.brown@example.com', 456890123, '101 Pine St, Thistown, USA', 12000.00, 'VIP customer'),
(5, 'Jessica', 'Williams', '2022-05-17', 30, 'jessica.williams@example.com', 578901234, '202 Maple St, Thatstown, USA', 3000.00, 'Occasional buyer'),
(6, 'David', 'Taylor', '2018-08-05', 45, 'david.taylor@example.com', 679012345, '303 Birch St, Anothertown, USA', 15000.00, 'Loyal customer'),
(7, 'Sarah', 'Moore', '2021-12-19', 27, 'sarah.moore@example.com', 789023456, '404 Cedar St, Somewhere, USA', 2500.00, 'Seasonal shopper'),
(8, 'Daniel', 'Anderson', '2017-06-25', 33, 'daniel.anderson@example.com', 890123567, '505 Walnut St, Everywhere, USA', 8000.00, 'Regular customer'),
(9, 'Laura', 'Thomas', '2019-02-10', 29, 'laura.thomas@example.com', 901234567, '606 Ash St, Thisplace, USA', 4000.00, 'Monthly buyer'),
(10, 'James', 'Jackson', '2020-09-14', 38, 'james.jackson@example.com', 123456789, '707 Spruce St, Thatplace, USA', 6000.00, 'Returning customer');


---VERIFY MY TABLE
SELECT * FROM CUSTOMER;


--NOTE: ABOVE TABLE-- CUSTOMER TABLE (WITHOUT CONSTRIANTS) --ABOVE


INSERT INTO CUSTOMER (CUSTOMER_ID, F_NAME, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, ADDRESSS, CREDIT_LIMIT, COMMENTS) VALUES
(1, 'John', 'Doe', '2021-01-15', 28, 'john.doe@example.com', 1234567890, '123 Main St, Anytown, USA', 5000.00, 'First customer');


INSERT INTO CUSTOMER (CUSTOMER_ID, F_NAME, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, ADDRESSS, CREDIT_LIMIT, COMMENTS) VALUES
(2, 'Trilochan', 'Das', '2022-05-17', 4, 'john.doe@example.com', 1234567890, '569 Hyd St, Anytown, Ameerpet', 10000.00, 'SeconD Customer');

---VERIFY MY TABLE
SELECT * FROM CUSTOMER;


--4) CREATION OF TABLE WITH CONSTRAINTS 
----------------------------------------

CREATE TABLE CUSTOMER_WC
(
CUSTOMER_ID		INT PRIMARY KEY IDENTITY,
F_NAME			VARCHAR(25) NOT NULL,
L_NAME			VARCHAR(25) NOT NULL,
JOIN_DATE		DATE NOT NULL,
AGE				TINYINT CHECK(AGE>=18),
EMAIL			VARCHAR(50) UNIQUE,
PHONE			VARCHAR(12) UNIQUE,
ADDRESSS		VARCHAR(100) DEFAULT 'INDIA',
CREDIT_LIMIT	DECIMAL(10,2),
COMMENTS		TEXT
);

SELECT * fROM CUSTOMER_WC;

INSERT INTO CUSTOMER_WC (F_NAME, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, ADDRESSS, CREDIT_LIMIT, COMMENTS) VALUES
('John', 'Doe', '2021-01-01', 30, 'john.doe@example.com', 1234567890, '123 Elm St, Springfield, USA', 1000.00, 'First customer')


INSERT INTO CUSTOMER_WC (F_NAME, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, ADDRESSS, CREDIT_LIMIT, COMMENTS) VALUES
('Jane', 'Smith', '2021-01-05', 28, 'jane.smith@example.com', 2345678901, '456 Oak St, Metropolis, USA', 1500.00, 'Second customer'),
('Alice', 'Johnson', '2021-01-10', 35, 'alice.johnson@example.com', 3456789012, '789 Pine St, Smallville, USA', 2000.00, 'Third customer'),
('Bob', 'Brown', '2021-01-15', 22, 'bob.brown@example.com', 4567890123, '321 Birch St, Gotham, USA', 1200.00, 'Fourth customer'),
('Charlie', 'Davis', '2021-01-20', 40, 'charlie.davis@example.com', 5678901234, '654 Cedar St, Star City, USA', 1800.00, 'Fifth customer'),
('David', 'Wilson', '2021-01-25', 27, 'david.wilson@example.com', 6789012345, '987 Spruce St, Central City, USA', 2200.00, 'Sixth customer'),
('Eve', 'Garcia', '2021-02-01', 29, 'eve.garcia@example.com', 7890123456, '135 Maple St, Coast City, USA', 1300.00, 'Seventh customer'),
('Frank', 'Martinez', '2021-02-05', 32, 'frank.martinez@example.com', 8901234567, '246 Walnut St, Starling City, USA', 1700.00, 'Eighth customer'),
('Grace', 'Hernandez', '2021-02-10', 26, 'grace.hernandez@example.com', 9012345678, '357 Cherry St, National City, USA', 1600.00, 'Ninth customer'),
('Henry', 'Lopez', '2021-02-15', 31, 'henry.lopez@example.com', 1234567809, '468 Palm St, Keystone City, USA', 1100.00, 'Tenth customer'),
('Ivy', 'Clark', '2021-02-20', 38, 'ivy.clark@example.com', 2345678910, '579 Ash St, Emerald City, USA', 2500.00, 'Eleventh customer'),
('Jack', 'Lewis', '2021-02-25', 24, 'jack.lewis@example.com', 3456789021, '680 Fir St, Riverdale, USA', 1400.00, 'Twelfth customer'),
('Kathy', 'Walker', '2021-03-01', 33, 'kathy.walker@example.com', 4567890132, '791 Fir St, Hill Valley, USA', 1900.00, 'Thirteenth customer'),
('Leo', 'Hall', '2021-03-05', 29, 'leo.hall@example.com', 5678901243, '902 Fir St, Sunnydale, USA', 1500.00, 'Fourteenth customer'),
('Mia', 'Allen', '2021-03-10', 27, 'mia.allen@example.com', 6789012354, '013 Fir St, Millville, USA', 2100.00, 'Fifteenth customer'),
('Nina', 'Young', '2021-03-15', 36, 'nina.young@example.com', 7890123465, '124 Fir St, Pleasantville, USA', 2300.00, 'Sixteenth customer'),
('Oscar', 'King', '2021-03-20', 25, 'oscar.king@example.com', 8901234576, '235 Fir St, Harmony, USA', 1200.00, 'Seventeenth customer'),
('Pam', 'Wright', '2021-03-25', 34, 'pam.wright@example.com', 9012345687, '346 Fir St, Chesterfield, USA', 1800.00, 'Eighteenth customer'),
('Quinn', 'Scott', '2021-04-01', 30, 'quinn.scott@example.com', 1234567891, '457 Fir St, Kingsport, USA', 1600.00, 'Nineteenth customer'),
('Rick', 'Adams', '2021-04-05', 41, 'rick.adams@example.com', 2345678902, '568 Fir St, Riverton, USA', 2000.00, 'Twentieth customer'),
('Sara', 'Baker', '2021-04-10', 23, 'sara.baker@example.com', 3456789013, '679 Fir St, Newtown, USA', 1100.00, 'Twenty-first customer'),
('Tom', 'Gonzalez', '2021-04-15', 39, 'tom.gonzalez@example.com', 4567890124, '780 Fir St, Riverside, USA', 1900.00, 'Twenty-second customer'),
('Uma', 'Nelson', '2021-04-20', 26, 'uma.nelson@example.com', 5678901235, '891 Fir St, Crestview, USA', 1400.00, 'Twenty-third customer'),
('Vera', 'Carter', '2021-04-25', 37, 'vera.carter@example.com', 6789012346, '902 Fir St, Maplewood, USA', 2200.00, 'Twenty-fourth customer'),
('Will', 'Mitchell', '2021-05-01', 29, 'will.mitchell@example.com', 7890123457, '013 Fir St, Lakeview, USA', 1500.00, 'Twenty-fifth customer');


INSERT INTO CUSTOMER_WC (F_NAME, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, ADDRESSS, CREDIT_LIMIT, COMMENTS) VALUES
('John', 'Doe', '2021-01-01', 30, 'DFDjohn.doe@example.com', 1234567896, '123 Elm St, Springfield, USA', 1000.00, 'First customer')



INSERT INTO CUSTOMER_WC (F_NAME, L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, CREDIT_LIMIT, COMMENTS) VALUES
('ASDFAROY', 'SAFDSoe', '2021-01-01', 23, 'DFAROYjohn.doe@example.com', 2234567896, 1000.00, 'First customer')

SELECT * fROM CUSTOMER_WC;

INSERT INTO CUSTOMER_WC (L_NAME, JOIN_DATE, AGE, EMAIL, PHONE, CREDIT_LIMIT, COMMENTS) VALUES
('SAFDSoe', '2021-01-01', 23, 'DFAROYjohn.doe@example.com', 2234567896, 1000.00, 'First customer')



---TESTING CONSTRAINTS :
IDENTITY : TESTED SUCESSFULLY
NOT NULL: TESTED SUCESSFULLY
DEFUALT: TESTED SUCESSFULLY

CHECK : TESTED SUCESSFULLY
UNIQUE:  TESTED SUCESSFULLY 
TRIGGER: LATER SESSIONS

PK : LATER ON 
FK : LATER ON 




